

import UIKit

class FilmesTableViewCell: UITableViewCell{
    
    @IBOutlet weak var capaImageView: UIImageView!
    @IBOutlet weak var tituloLabel: UILabel!
    @IBOutlet weak var generoLabel: UILabel!
    
    @IBOutlet weak var diretorLabel: UILabel!
}
