//
//  ViewController.swift
//  ProjetoFilmes
//
//  Created by Arthur on 27/08/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

